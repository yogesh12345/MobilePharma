# PharmaSys Mobile

React mobile interface for PharmaSys. The same source can be built for a phone
browser as an installable PWA or packaged with Capacitor for Android and iOS.

## Browser build

```bash
npm ci
npm run build:web
```

The browser build is served at `/mobile-app/` on the PharmaSys API HTTPS host.
See [WEB_DEPLOY.md](WEB_DEPLOY.md) for the Linux and Nginx deployment steps.

## Local development

```bash
npm ci
npm run dev
```

Local development uses `VITE_API_BASE_URL` from `.env`. To point it at another
API, set that variable in `.env.local`. The standard `npm run build` still uses
the usual Vite configuration for Capacitor; `npm run build:web` uses `.env.web`
and the `/mobile-app/` base path.
