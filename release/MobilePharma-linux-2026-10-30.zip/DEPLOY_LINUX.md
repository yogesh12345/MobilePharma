# MobilePharma Linux deployment

This archive contains a ready-to-serve browser build in `dist/` and source files
in `source/`. It is built for `/mobile-app/` with same-origin API calls.

Target mobile browser URL after deployment:
https://back.meenaagencies.co.in/mobile-app/

The target URL returned HTTP 404 when this archive was created. Deployment and
server routing are required before it will open. The hostname resolved to a
private IP from the build machine; verify public DNS and HTTPS reachability
from a mobile network if the URL must work over the public internet.

## Deploy the prebuilt browser app

Unzip this archive on the Linux server, then from the extracted directory:

    sudo mkdir -p /var/www/mobile-app
    sudo rsync -a --delete dist/ /var/www/mobile-app/

Merge `source/deploy/nginx-mobile-app.conf` into the existing HTTPS Nginx
server block for `back.meenaagencies.co.in`. Keep the API proxy locations
outside `/mobile-app/` intact. Then run:

    sudo nginx -t
    sudo systemctl reload nginx
    curl -I https://back.meenaagencies.co.in/mobile-app/

The URL should return HTTP 200 and its HTML should reference assets under
`/mobile-app/assets/`. Open it on the phone and sign in. The Go API must be
available on the same HTTPS host for login and data requests.

## Rebuild from source on Linux

Node.js and npm are needed. From the extracted directory:

    cd source
    npm ci
    npm run build:web
    sudo rsync -a --delete dist/ /var/www/mobile-app/

The build uses `source/.env.web` and emits files for `/mobile-app/`.
Do not deploy the `source/` directory as the web root.

## Backend compatibility

`backend-patch/sales-order-search-full-item.patch` contains the companion
Go API change for immediate Sales Order item selection. Apply it in the
matching PharmaSys backend repository, build and restart that backend using
its normal deployment process. Older backends still work with a fallback
item-detail request, but selecting a searched item can be slower.

See `source/WEB_DEPLOY.md` for more context.
