import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import API from "../services/api";
import CompaniesPage from "./CompaniesPage";
import SalesOrderPage from "./SalesOrderPage";
import RecentPurchases from "./RecentPurchases";
import type { PurchaseInvoice } from "./RecentPurchases";

type View = "home" | "companies" | "orders" | "credit" | "purchases" | "outstanding";
type Invoice = PurchaseInvoice;
type CreditRequest = { id: number; invoiceNo: string; reason: string; status: string };
type OutstandingInvoice = { invoiceNo: string; invoiceDate: string; invoiceAmount: number; balanceAmount: number };

const outstandingDate = (value: string) => {
  const match = value?.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return match && match[1] !== "0000" && match[1] !== "0001"
    ? `${match[3]}/${match[2]}/${match[1].slice(2)}`
    : "—";
};
const outstandingMoney = (value: number) =>
  Number(value || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const outstandingStatus = (invoice: OutstandingInvoice): "PENDING" | "PART" => {
  const paid = Math.max(0, Number(invoice.invoiceAmount) - Number(invoice.balanceAmount));
  return paid <= 0.000001 ? "PENDING" : "PART";
};

const box = "rounded-2xl border border-slate-200 bg-white p-4 shadow-sm";
const input = "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-100";

export default function CustomerPortalPage({ linked, onOpenProfile }: { linked: boolean; onOpenProfile: () => void }) {
  const [view, setView] = useState<View>("home");
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [requests, setRequests] = useState<CreditRequest[]>([]);
  const [outstanding, setOutstanding] = useState<OutstandingInvoice[]>([]);
  const [invoiceKey, setInvoiceKey] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const visibleView = !linked && view !== "home" && view !== "companies" ? "home" : view;

  useEffect(() => {
    if ((view !== "credit" && view !== "purchases") || !linked) return;
    let active = true;
    Promise.all([API.get("/mobile/customer-portal/invoices"), view === "credit" ? API.get("/mobile/customer-portal/credit-note-requests") : Promise.resolve(null)])
      .then(([invoiceResult, requestResult]) => {
        if (!active) return;
        setInvoices(invoiceResult.data.invoices ?? []);
        if (requestResult) setRequests(requestResult.data.requests ?? []);
      }).catch(() => { if (active) setError("Unable to load invoices or requests."); });
    return () => { active = false; };
  }, [view, linked]);

  useEffect(() => {
    if (view !== "outstanding" || !linked) return;
    let active = true;
    API.get("/mobile/customer-portal/outstanding").then(({ data }) => { if (active) setOutstanding(data.invoices ?? []); })
      .catch(() => { if (active) setError("Unable to load outstanding invoices."); });
    return () => { active = false; };
  }, [view, linked]);

  const raiseCreditRequest = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setError(""); setMessage(""); setBusy(true);
    try {
      const [invoiceYear, invoiceId] = invoiceKey.split(":").map(Number);
      await API.post("/mobile/customer-portal/credit-note-requests", { invoiceId, invoiceYear, reason });
      setInvoiceKey(""); setReason(""); setMessage("Credit note request submitted for review.");
      const list = await API.get("/mobile/customer-portal/credit-note-requests"); setRequests(list.data.requests ?? []);
    } catch (err: unknown) {
      const e = err as { response?: { data?: { error?: string } } };
      setError(e.response?.data?.error ?? "Unable to submit request.");
    } finally { setBusy(false); }
  };

  return <section className="mx-auto w-full max-w-3xl space-y-4 px-4 py-5">
    {visibleView !== "home" && <button type="button" onClick={() => { setView("home"); setError(""); setMessage(""); }} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold">Back to home</button>}
    {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
    {message && <p role="status" className="rounded-xl bg-green-50 p-3 text-sm text-green-800">{message}</p>}
    {visibleView === "home" && <>
      {!linked && <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">The company catalog is available now. Activate your customer profile to place orders. <button type="button" className="font-bold underline" onClick={onOpenProfile}>Open profile</button></div>}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <button type="button" onClick={() => setView("companies")} className={`${box} min-h-32 text-left font-semibold text-blue-900`}>Companies</button>
        {linked && <button type="button" onClick={() => setView("orders")} className={`${box} min-h-32 text-left font-semibold text-violet-900`}>Sales Order</button>}
        {linked && <button type="button" onClick={() => setView("credit")} className={`${box} min-h-32 text-left font-semibold text-rose-900`}>Raise credit note</button>}
        {linked && <button type="button" onClick={() => setView("purchases")} className={`${box} min-h-32 text-left font-semibold text-emerald-900`}>Recent purchases</button>}
        {linked && <button type="button" onClick={() => setView("outstanding")} className={`${box} min-h-32 text-left font-semibold text-amber-900`}>Outstanding invoices</button>}
      </div>
    </>}
    {visibleView === "companies" && <CompaniesPage canUpdateCompany={false} canUpdateRack={false} />}
    {visibleView === "orders" && linked && <SalesOrderPage customerProfileMode />}
    {visibleView === "credit" && linked && <><h2 className="text-xl font-bold">Raise a credit note request</h2><form onSubmit={raiseCreditRequest} className={`${box} space-y-4`}><p className="text-sm text-slate-600">Select one of your invoices and describe the issue. Your request will be reviewed before a credit note is issued.</p><select required className={input} value={invoiceKey} onChange={e => setInvoiceKey(e.target.value)}><option value="">Select invoice</option>{invoices.map(invoice => <option key={`${invoice.invoiceYear}:${invoice.id}`} value={`${invoice.invoiceYear}:${invoice.id}`}>{invoice.invoiceNo} · ₹{Number(invoice.amount).toLocaleString("en-IN")}</option>)}</select><textarea required minLength={10} maxLength={1000} rows={4} className={input} value={reason} onChange={e => setReason(e.target.value)} placeholder="Reason for credit note request" /><button disabled={busy} type="submit" className="rounded-lg bg-blue-700 px-4 py-2.5 font-semibold text-white disabled:opacity-60">{busy ? "Submitting..." : "Submit request"}</button></form><h3 className="font-bold">Recent requests</h3><div className="space-y-2">{requests.map(request => <div className={box} key={request.id}><strong>{request.invoiceNo}</strong><span className="ml-2 text-sm text-slate-600">{request.status}</span><p className="mt-1 text-sm">{request.reason}</p></div>)}{!requests.length && <p className="text-sm text-slate-500">No requests yet.</p>}</div></>}
    {visibleView === "purchases" && linked && <RecentPurchases invoices={invoices} />}
    {visibleView === "outstanding" && linked && <>
      <h2 className="text-xl font-bold">Outstanding invoices</h2>
      {outstanding.length ? (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
          <table className="w-full min-w-[540px] border-collapse text-left text-xs sm:text-sm">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="whitespace-nowrap px-3 py-3 font-semibold">Invoice Date</th>
                <th className="whitespace-nowrap px-3 py-3 font-semibold">Invoice No.</th>
                <th className="whitespace-nowrap px-3 py-3 text-right font-semibold">Invoice Amount / Balance</th>
                <th className="whitespace-nowrap px-3 py-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {outstanding.map((invoice, index) => {
                const status = outstandingStatus(invoice);
                const partPaid = status === "PART";
                return <tr key={`${invoice.invoiceNo}:${index}`} className={index % 2 ? "bg-slate-50/70" : "bg-white"}>
                  <td className="whitespace-nowrap px-3 py-3 text-slate-700">{outstandingDate(invoice.invoiceDate)}</td>
                  <td className="whitespace-nowrap px-3 py-3 font-semibold text-slate-900">{invoice.invoiceNo}</td>
                  <td className="whitespace-nowrap px-3 py-3 text-right tabular-nums">
                    <span className="block font-semibold text-slate-900">₹{outstandingMoney(partPaid ? invoice.balanceAmount : invoice.invoiceAmount)}</span>
                    <span className="text-xs text-slate-500">{partPaid ? "Balance" : "Invoice amount"}</span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-3">
                    <span className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold ${partPaid ? "bg-amber-100 text-amber-900" : "bg-blue-50 text-blue-800"}`}>
                      {status}
                    </span>
                  </td>
                </tr>;
              })}
            </tbody>
          </table>
        </div>
      ) : <p className="text-sm text-slate-500">No outstanding invoices found.</p>}
    </>}
  </section>;
}
