# MobilePharma domain bundle

The ready-built website is in `dist/`; source is in `source/`.
Read `source/MOBILE_DOMAIN_DEPLOY.md` before replacing the live site.

To rebuild after extracting:

    cd source
    npm ci
    npm run build:mobile-domain

The generated `source/dist/` then replaces the bundled `dist/`.
