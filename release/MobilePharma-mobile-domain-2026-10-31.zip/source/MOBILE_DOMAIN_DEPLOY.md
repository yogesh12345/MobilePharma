# Deploy to mobile.meenaagencies.co.in

This hostname serves the mobile app at `/`. The existing `build:web` target is
for the older `/mobile-app/` path on the API host; use the dedicated target here.

The deployment ZIP in `release/MobilePharma-mobile-domain-2026-10-31.zip`
contains a ready-built `dist/` plus a `source/` directory. On Linux, extract it
first. Run `npm` only from `source/`, where `package.json` is located; the top
level of the extracted bundle has no `package.json`.

## Build

```bash
npm ci
npm run build:mobile-domain
```

Copy the **contents** of `dist/` to `/var/www/mobilepharma/` on the HTTPS host.
The generated `index.html` must refer to `/assets/...`, `/manifest.webmanifest`,
and `/sw.js`, with no `/mobile-app/` prefix.

## Current pharma-server setup

The public HTTPS proxy forwards the mobile hostname to the existing Nginx
listener on port 8082. That listener is configured in
`/etc/nginx/sites-enabled/mobile-app`; use
`deploy/nginx-pharma-server-8082.conf` as its server block. Its document root is
`/var/www/mobilepharma`, and its API routes proxy to the local Go backend on
port 8081. From the extracted `source/` directory, deploy the build with:

```bash
sh scripts/deploy-mobile-domain.sh
```

The script runs `npm ci`, TypeScript, and Vite directly with the `/` base path,
then copies `dist/` to
`/var/www/mobilepharma/`. Nginx does not need a reload when only the static app
files change.

The browser uses the mobile hostname for both app files and API requests, so
browser CORS is not needed for the current proxy route. A test POST to `/login`
with invalid credentials returned the expected JSON HTTP 401 on 31 October
2026. If a later proxy change forwards an Origin header that the backend denies,
add `https://mobile.meenaagencies.co.in` to the backend's `CORS_ALLOW_ORIGINS`.

## Alternative direct HTTPS Nginx setup

1. Point the `mobile.meenaagencies.co.in` DNS record at the HTTPS web server and
   ensure its TLS certificate covers this hostname.
2. Add the locations in `deploy/nginx-mobile-domain.conf` to that hostname's
   HTTPS Nginx/OpenResty server block. Adapt the `root` path if needed. The API
   routes proxy to the existing `back.meenaagencies.co.in` service; the app files
   are served locally. If the web server and Go backend are on the same machine,
   `http://127.0.0.1:8081` can be used as the API proxy target instead.
3. Add `https://mobile.meenaagencies.co.in` to the backend's
   `CORS_ALLOW_ORIGINS` alongside existing origins, then restart the backend.
   Keep `REQUIRE_DESKTOP_SHELL_PROOF` disabled for ordinary browser access.
4. Check the server configuration and reload it:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

If using a hosting control panel instead of editing Nginx directly, configure
the same document root, API proxy routes, HTTPS certificate, and cache behavior
there. Do not serve the Vite development process on port 8082 publicly.

## Verify

```bash
curl -I https://mobile.meenaagencies.co.in/
curl -I https://mobile.meenaagencies.co.in/manifest.webmanifest
curl https://mobile.meenaagencies.co.in/api/health
```

The health request should return the Go API's JSON, not the app's `index.html`
or a 404. Open the site in a private browser window, sign in, and check that
scripts, styles, login, and a PDF request load on the mobile hostname. Then
check installation from a phone over HTTPS.
